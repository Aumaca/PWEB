// Função para calcular a média do aluno
function calcularMedia() {
    let nome = prompt("Digite seu nome:");

    // Se o usuário cancelar ou deixar o nome em branco, encerra a função
    if (nome === null || nome.trim() === "") {
        return;
    }

    let notas = [];

    for (let i = 1; i <= 4; i++) {
        let nota;
        while (true) {
            try {
                nota = prompt(`Digite a nota ${i}:`);
                
                // Se o usuário cancelar, interrompe a função
                if (nota === null) {
                    return;
                }

                nota = parseFloat(nota);

                if (isNaN(nota) || nota < 0 || nota > 10) {
                    throw new Error("Nota inválida! Digite um número entre 0 e 10.");
                }

                break; // Sai do loop se a nota for válida
            } catch (error) {
                alert(error.message);
            }
        }

        notas.push(nota);
    }

    let media = notas.reduce((acc, val) => acc + val, 0) / notas.length;
    alert(`${nome}, sua média é: ${media.toFixed(2)}`);
}
