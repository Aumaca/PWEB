function calcularOperacoes() {
    // Pede dois números ao usuário
    let num1 = parseFloat(prompt("Digite o primeiro número:"));
    let num2 = parseFloat(prompt("Digite o segundo número:"));

    // Verifica se os valores são válidos
    if (isNaN(num1) || isNaN(num2)) {
        alert("Você precisa inserir números válidos.");
        return;
    }

    let operacoes = `
    Soma: ${num1} + ${num2} = ${num1 + num2}
    Subtração: ${num1} - ${num2} = ${num1 - num2}
    Multiplicação: ${num1} * ${num2} = ${num1 * num2}
    Divisão: ${num1} / ${num2} = ${num2 !== 0 ? (num1 / num2) : "Erro (divisão por zero)"}
    Resto da divisão: ${num1} % ${num2} = ${num2 !== 0 ? (num1 % num2) : "Erro (divisão por zero)"}    
    `;

    alert(operacoes);
}
